<?php
	define('USER_TYPES', array(
		'admin' => '0',
		'manager' => '1',
		'employee' => '2',				
	));

	
	define('BASE_URL', url('/').'/');
?>