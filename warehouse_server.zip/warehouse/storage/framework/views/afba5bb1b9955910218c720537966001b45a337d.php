
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-10 text-center">
                <h4>View Load</h4>
                <?php if(session()->has('message')): ?>
                    <div class="alert alert-success text-center">
                        <?php echo e(session()->get('message')); ?>

                    </div>
                <?php endif; ?>
                <?php if(session()->has('error')): ?>
                    <div class="alert alert-danger text-center">
                        <?php echo e(session()->get('error')); ?>

                    </div>
                <?php endif; ?>
            </div>

            <div class="col-md-2">
                <a href="<?php echo e(route('admin.inoutloads.index')); ?>" class = "btn btn-primary" ><i class = "fa fa-backward"></i> Back</a>
            </div>

        </div>
        <br>
        <div class="row">
            <div class="col-md-12">
                <h4>Load Details</h4>
                <table class="table table-sm table-hover">
                    <tbody>
                        <tr>
                            <td style = "width: 500px;">Load ID</td>
                            <td><?php echo e($load->id); ?></td>
                        </tr>
                        <tr>
                            <td>Customer</td>
                            <td><?php echo e($load->customer->customer_name); ?></td>
                        </tr>

                        <tr>
                            <td>Location</td>
                            <td>
                                <?php if($load->location): ?>
                                <?php echo e($load->location); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>

                          <tr>
                            <td>Bill To</td>
                            <td>
                                <?php if($load->bill_to_id): ?>
                                <?php echo e($load->bill_to->customer_name); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>

                         <tr>
                            <td>In-Out-Load</td>
                            <td>
                                <?php if($load->in_out_load): ?>
                                <?php echo e($load->in_out_load); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>

                         <tr>
                            <td>Load Project Control No.</td>
                            <td>
                                <?php if($load->load_project_control_no): ?>
                                <?php echo e($load->load_project_control_no); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>

                         <tr>
                            <td>Load Project Date</td>
                            <td>
                                <?php if($load->load_project_date): ?>
                                <?php echo e(\Carbon\Carbon::parse($load->load_project_date)->format('Y-m-d')); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>

                         <tr>
                            <td>Begin Case Ct</td>
                            <td>
                                <?php if($load->begin_case_ct): ?>
                                <?php echo e($load->begin_case_ct); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>

                         <tr>
                            <td>Ending Case Ct</td>
                            <td>
                                <?php if($load->ending_case_ct): ?>
                                <?php echo e($load->ending_case_ct); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>

                         <tr>
                            <td>Begin Pallet Ct</td>
                            <td>
                                <?php if($load->begin_pallet_ct): ?>
                                <?php echo e($load->begin_pallet_ct); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>

                         <tr>
                            <td>Ending Pallet Ct</td>
                            <td>
                                <?php if($load->ending_pallet_ct): ?>
                                <?php echo e($load->ending_pallet_ct); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <td>Begin Ship Packs</td>
                            <td>
                                <?php if($load->begin_ship_packs): ?>
                                <?php echo e($load->begin_ship_packs); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <td>Ending Ship Packs</td>
                            <td>
                                <?php if($load->ending_ship_packs): ?>
                                <?php echo e($load->ending_ship_packs); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <td>Trailer Type</td>
                            <td>
                                <?php if($load->trailer_type): ?>
                                <?php echo e($load->trailer_type); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <td>Trailer Size</td>
                            <td>
                                <?php if($load->trailer_size): ?>
                                <?php echo e($load->trailer_size); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>
                         <tr>
                            <td>Load Project Trip No.</td>
                            <td>
                                <?php if($load->load_project_trip_no): ?>
                                <?php echo e($load->load_project_trip_no); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>

                         <tr>
                            <td>Driver Name</td>
                            <td>
                                <?php if($load->driver_id): ?>
                                <?php echo e($load->driver->first_name .' '. $load->driver->last_name); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>
                         <tr>
                            <td>Shift</td>
                            <td>
                                <?php if($load->shift): ?>
                                <?php echo e($load->shift); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>
                         <tr>
                            <td>Payment Type</td>
                            <td>
                                <?php if($load->payment_type): ?>
                                <?php echo e($load->payment_type); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>
                         <tr>
                            <td>Load/Project Type</td>
                            <td>
                                <?php if($load->load_project_type): ?>
                                <?php echo e($load->load_project_type); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>
                         <tr>
                            <td>Weight</td>
                            <td>
                                <?php if($load->weight): ?>
                                <?php echo e($load->weight); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>
                         <tr>
                            <td>Pieces</td>
                            <td>
                                <?php if($load->pieces): ?>
                                <?php echo e($load->pieces); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>
                         <tr>
                            <td>Pallets In</td>
                            <td>
                                <?php if($load->pallets_in): ?>
                                <?php echo e($load->pallets_in); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>
                         <tr>
                            <td>Carrier</td>
                            <td>
                                <?php if($load->carrier): ?>
                                <?php echo e($load->carrier); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>
                         <tr>
                            <td>Trailer No.</td>
                            <td>
                                <?php if($load->trailer_no): ?>
                                <?php echo e($load->trailer_no); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>
                         <tr>
                            <td>Dock</td>
                            <td>
                                <?php if($load->dock): ?>
                                <?php echo e($load->dock); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>
                         <tr>
                            <td>Truck No.</td>
                            <td>
                                <?php if($load->truck_no): ?>
                                <?php echo e($load->truck_no); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>
                         <tr>
                            <td>Door No.</td>
                            <td>
                                <?php if($load->door_no): ?>
                                <?php echo e($load->door_no); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>
                         <tr>
                            <td>Trip No.</td>
                            <td>
                                <?php if($load->trip_no): ?>
                                <?php echo e($load->trip_no); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>
                         <tr>
                            <td>Total Skus</td>
                            <td>
                                <?php if($load->total_skus): ?>
                                <?php echo e($load->total_skus); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>
                         <tr>
                            <td>Po No.</td>
                            <td>
                                <?php if($load->po_no): ?>
                                <?php echo e($load->po_no); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>
                         <tr>
                            <td>Bol Shipment No.</td>
                            <td>
                                <?php if($load->bol_shipment_no): ?>
                                <?php echo e($load->bol_shipment_no); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>
                          <tr>
                            <td>Shipper</td>
                            <td>
                                <?php if($load->shipper): ?>
                                <?php echo e($load->shipper); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <td>Vendor</td>
                            <td>
                                <?php if($load->vendor): ?>
                                <?php echo e($load->vendor); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>
                          <tr>
                            <td>Project Start Time</td>
                            <td>
                                <?php if($load->project_start_time): ?>
                                <?php echo e(\Carbon\Carbon::parse($load->project_start_time)->format('H:i')); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>
                          <tr>
                            <td>Project End Time</td>
                            <td>
                                <?php if($load->project_end_time): ?>
                                <?php echo e(\Carbon\Carbon::parse($load->project_end_time)->format('H:i')); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>
                          <tr>
                            <td>Check Type</td>
                            <td>
                                <?php if($load->check_type): ?>
                                <?php echo e($load->check_type); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>
                         <tr>
                            <td>Check Number</td>
                            <td>
                                <?php if($load->check_number): ?>
                                <?php echo e($load->check_number); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <td>Late No Show Charge</td>
                            <td>
                                <?php if($load->late_no_show_charge): ?>
                                <?php echo e($load->late_no_show_charge); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <td>Repalletize Pallets</td>
                            <td>
                                <?php if($load->repalletize_pallets): ?>
                                <?php echo e($load->repalletize_pallets); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <td>Repalletize Charge</td>
                            <td>
                                <?php if($load->repalletize_charge): ?>
                                <?php echo e($load->repalletize_charge); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <td>Bad Pallets</td>
                            <td>
                                <?php if($load->bad_pallets): ?>
                                <?php echo e($load->bad_pallets); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <td>Bad Pallet Charge</td>
                            <td>
                                <?php if($load->bad_pallet_charge): ?>
                                <?php echo e($load->bad_pallet_charge); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <td>Reload Charge</td>
                            <td>
                                <?php if($load->reload_charge): ?>
                                <?php echo e($load->reload_charge); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <td>Special Charges</td>
                            <td>
                                <?php if($load->special_charges): ?>
                                <?php echo e($load->special_charges); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>
                        
                        <?php if(empty($pays) || $pays->count() >0): ?>

                        <?php if($pays[0]->pay_system === 'percentage'): ?>

                        <tr>
                            <td>Charged Amount</td>
                            <td>
                                <?php if($load->charge_amount): ?>
                                <?php echo e($load->charge_amount); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>

                        <tr>
                            <td>Rebate Percentage</td>
                            <td>
                                <?php if($load->rebate_percentage): ?>
                                <?php echo e($load->rebate_percentage); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>

                        <tr>
                            <td>Total Income Less Rebate</td>
                            <td>
                                <?php if($load->total_income_less_rebate): ?>
                                <?php echo e($load->total_income_less_rebate); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>

                        <tr>
                            <td>Employee Percentage</td>
                            <td>
                                <?php if($load->employee_percentage): ?>
                                <?php echo e($load->employee_percentage); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>

                        <tr>
                            <td>Employees Total Pay</td>
                            <td>
                                <?php if($load->employee_total_pay): ?>
                                <?php echo e($load->employee_total_pay); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endif; ?>
                        <?php endif; ?>
                        


                        

                       <br>
                       <br>
                       <?php if(empty($pays) || $pays->count() >0): ?>
                       <?php if(isset($pays)): ?>
                       <tr>
                        <td>Pay System</td>
                        <td>
                            <?php if($pays[0]->pay_system): ?>
                            <?php echo e(ucfirst($pays[0]->pay_system)); ?>

                            <?php else: ?>
                            N/A
                            <?php endif; ?>
                        </td>
                    </tr>
                       <?php $__currentLoopData = $pays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                        <?php if($pay->pay_system == 'hourly'): ?>

                            <tr>
                              <td>Associate Name</td>
                              <td>
                                <?php if($pay->associate_id): ?>
                                <?php echo e($pay->associate->first_name .' '.$pay->associate->last_name); ?>

                                
                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                              </td>
                            </tr>

                            <tr>
                                <td>Associate SSN</td>
                                <td>
                                  <?php if($pay->ssn_associate): ?>
                                  <?php echo e($pay->ssn_associate); ?>

                                  <?php else: ?>
                                  N/A
                                  <?php endif; ?>
                                </td>
                            </tr>


                            <tr>
                                <td>Hourly Pay</td>
                                <td>
                                  <?php if($pay->hourly_pay): ?>
                                  <?php echo e($pay->hourly_pay); ?>

                                  <?php else: ?>
                                  N/A
                                  <?php endif; ?>
                                </td>
                            </tr>


                            <tr>
                                <td>Working Hours</td>
                                <td>
                                  <?php if($pay->hours): ?>
                                  <?php echo e($pay->hours); ?>

                                  <?php else: ?>
                                  N/A
                                  <?php endif; ?>
                                </td>
                            </tr>


                            <tr>
                                <td>Total Pay</td>
                                <td>
                                  <?php if($pay->payout_associate): ?>
                                  <?php echo e($pay->payout_associate); ?>

                                  <?php else: ?>
                                  N/A
                                  <?php endif; ?>
                                </td>
                            </tr>

                        <?php endif; ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php
                        $no = 0;
                        ?>

                    <?php $__currentLoopData = $pays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <?php
                            $no++;
                            ?>

                        <?php if($pay->pay_system == 'percentage'): ?>

                            <tr>
                                <td><?php echo e($no.' - '); ?>Associate Name</td>
                                <td>
                                <?php if($pay->associate_id): ?>
                                <?php echo e($pay->associate->first_name .' '.$pay->associate->last_name); ?>

                                
                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                                </td>
                            </tr>

                            <tr>
                                <td>Associate SSN</td>
                                <td>
                                <?php if($pay->ssn_associate): ?>
                                <?php echo e($pay->ssn_associate); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                                </td>
                            </tr>

                            <tr>
                                <td>Associate Percentage</td>
                                <td>
                                <?php if($pay->pay_percentage_associate): ?>
                                <?php echo e($pay->pay_percentage_associate); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                                </td>
                            </tr>


                            <tr>
                                <td>Associate Pay</td>
                                <td>
                                <?php if($pay->payout_associate): ?>
                                <?php echo e($pay->payout_associate); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                                </td>
                            </tr>

                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\warehouse\resources\views/admin/inoutloads/show.blade.php ENDPATH**/ ?>