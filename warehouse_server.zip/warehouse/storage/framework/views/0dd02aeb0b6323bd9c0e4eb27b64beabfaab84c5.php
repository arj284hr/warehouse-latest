
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-11 text-center">
                <h4>All Inbound/Outbound Loads</h4>
                <?php if(session()->has('message')): ?>
                    <div class="alert alert-success text-center">
                        <?php echo e(session()->get('message')); ?>

                    </div>
                <?php endif; ?>
                <?php if(session()->has('error')): ?>
                    <div class="alert alert-danger text-center">
                        <?php echo e(session()->get('error')); ?>

                    </div>
                <?php endif; ?>
            </div>
            <div class="col-md-1">
                <a href="<?php echo e(route('manager.inoutloads.create')); ?>" class = "btn btn-sm btn-primary" >Add New <i class = "fa fa-plus"></i></a>
            </div>
        </div>
      
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.manager.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/tap4trip/public_html/warehouse/resources/views/manager/inoutloads/index.blade.php ENDPATH**/ ?>