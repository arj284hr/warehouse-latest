
         
      
       
       
      

         
      

             
              
     
    




     <div class="l-navbar show" id="nav-bar">
    <nav class="nav">
        <div>
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="nav__logo border-bottom text-decoration-none text-dark">
                
                <i class="fas fa-warehouse"></i>
                <span class="nav__logo-name">Exe Data Center</span>
            </a>

            <div class="nav__list">
              <ul class="nav flex-column flex-nowrap overflow-hidden">
                <li class="nav-item">
                    <a class="nav-link text-truncate nav__link" href="<?php echo e(route('admin.dashboard')); ?>">
                        <i class="fas fa-tachometer-alt"></i>
                        <span class="d-none d-sm-inline nav__name">Dashboard</span>
                    </a>
                </li>
                 <li class="nav-item">
                    <a class="nav-link text-truncate nav__link" href="<?php echo e(route('admin.warehouse.index')); ?>">
                        <i class="fas fa-users"></i>
                        <span class="d-none d-sm-inline nav__name">Customers</span>
                    </a>
                </li>
                 <li class="nav-item">
                    <a class="nav-link text-truncate nav__link" href="<?php echo e(route('admin.departments.index')); ?>">
                        <i class="fa fa-plus-square"></i>
                        <span class="d-none d-sm-inline nav__name">Products</span>
                    </a>
                </li>
                  <li class="nav-item">
                    <a class="nav-link text-truncate nav__link" href="<?php echo e(route('admin.manager.index')); ?>">
                        <i class="fas fa-user-tie"></i>
                        <span class="d-none d-sm-inline nav__name">Managers</span>
                    </a>
                </li>
                 <li class="nav-item">
                    <a class="nav-link text-truncate nav__link" href="<?php echo e(route('admin.employee.index')); ?>">
                        <i class="fas fa-user-tie"></i>
                        <span class="d-none d-sm-inline nav__name">Employees</span>
                    </a>
                </li>
                 <li class="nav-item">
                    <a class="nav-link text-truncate nav__link" href="<?php echo e(route('admin.inoutloads.index')); ?>">
                        <i class="fa fa-cart-plus"></i>
                        <span class="d-none d-sm-inline nav__name">Loads</span>
                       
                    </a>
                </li>
                 <li class="nav-item">
                    <a class="nav-link nav-link2 collapsed  nav__link" href="#submenu1" data-toggle="collapse" data-target="#submenu1">
                        <i class="fas fa-file-invoice"></i>
                        <span class="d-none d-sm-inline nav__name">Invoicing Reports</span>
                    </a>
                    <div class="collapse" id="submenu1" aria-expanded="false">
                        <ul class="flex-column pl-2 nav">
                            <li class="nav-item">
                                <a class="nav-link nav-link2 py-0 text-muted" href="<?php echo e(route('admin.customer-invoice')); ?>">
                                    <i class="fa fa-cutlery nav-icon"></i>
                                    <span>Customer Invoice</span>
                                </a>
                            </li>
                             <li class="nav-item">
                                <a class="nav-link nav-link2 py-0 text-muted" href="<?php echo e(route('admin.carrier-invoice')); ?>">
                                    <i class="fa fa-cutlery nav-icon"></i>
                                    <span>Carrier Invoice</span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link nav-link2 py-0 text-muted" href="<?php echo e(route('admin.driver-invoice')); ?>">
                                    <i class="nav-icon fa fa-commen"></i>
                                    <span>Driver Invoice</span></a>
                            </li>
                            </ul>
                        </div>
                    </li>
                       <li class="nav-item">
                    <a class="nav-link nav-link2 collapsed  nav__link" href="#submenu2" data-toggle="collapse" data-target="#submenu2">
                        <i class="fas fa-file-invoice"></i>
                        <span class="d-none d-sm-inline nav__name">Payroll Reports</span>
                    </a>
                    <div class="collapse" id="submenu2" aria-expanded="false">
                        <ul class="flex-column pl-2 nav">
                            <li class="nav-item">
                                <a class="nav-link nav-link2 py-0 text-muted" href="<?php echo e(route('admin.hourly-report')); ?>">
                                    <i class="fa fa-cutlery nav-icon"></i>
                                    <span>Hourly Only</span>
                                </a>
                            </li>
                             <li class="nav-item">
                                <a class="nav-link nav-link2 py-0 text-muted" href="<?php echo e(route('admin.fix-report')); ?>">
                                    <i class="fa fa-cutlery nav-icon"></i>
                                    <span>Fixed Only</span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link nav-link2 py-0 text-muted" href="<?php echo e(route('admin.hourly-fix-report')); ?>">
                                    <i class="nav-icon fa fa-commen"></i>
                                    <span>Hourly/Fixed</span></a>
                            </li>
                            </ul>
                        </div>
                    </li>
                        <li class="nav-item">
                    <a class="nav-link nav-link2 collapsed  nav__link" href="#submenu3" data-toggle="collapse" data-target="#submenu3">
                        <i class="fas fa-file-invoice"></i>
                        <span class="d-none d-sm-inline nav__name">Productivity Reports</span>
                    </a>
                    <div class="collapse" id="submenu3" aria-expanded="false">
                        <ul class="flex-column pl-2 nav">
                            <li class="nav-item">
                                <a class="nav-link nav-link2 py-0 text-muted" href="<?php echo e(route('admin.load-revenue')); ?>">
                                    <i class="fa fa-cutlery nav-icon"></i>
                                    <span>Load Revenue Rebate</span>
                                </a>
                            </li>
                             <li class="nav-item">
                                <a class="nav-link nav-link2 py-0 text-muted" href="<?php echo e(route('admin.load-productivity')); ?>">
                                    <i class="fa fa-cutlery nav-icon"></i>
                                    <span>Load Productivity</span>
                                </a>
                            </li>
                            </ul>
                        </div>
                    </li> 
                 <li class="nav-item">
                    <a class="nav-link text-truncate nav__link" href="https://joinhomebase.com" target="_blank">
                        <i class="fa fa-link"></i>
                        <span class="d-none d-sm-inline nav__name">Join Homebase</span>
                    </a>
                </li>
                 <li class="nav-item">
                    <a class="nav-link text-truncate nav__link"  href="https://emgr.efsllc.com/mgnt/CheckAuthorization.action?_ga=2.230029080.569485358.1614876550-800784614.1614876550" target="_blank">
                        <i class="fa fa-link"></i>
                        <span class="d-none d-sm-inline nav__name">EFS</span>
                    </a>
                </li>
           

               

               
                
                            </ul>

                        </div>
                    </div>
                </nav>
            </div>

<?php /**PATH C:\xampp\htdocs\warehouse\resources\views/layouts/admin/sidenav.blade.php ENDPATH**/ ?>