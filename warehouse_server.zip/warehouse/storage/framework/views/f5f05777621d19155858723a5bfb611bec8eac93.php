<?php $__env->startSection('content'); ?>
    <div class="container-fluid" style="margin-top:140px;">
        <div class="row">
            <div class="col-md-10 text-center">
                <h4>View Manager</h4>
                <?php if(session()->has('message')): ?>
                    <div class="alert alert-success text-center">
                        <?php echo e(session()->get('message')); ?>

                    </div>
                <?php endif; ?>
                <?php if(session()->has('error')): ?>
                    <div class="alert alert-danger text-center">
                        <?php echo e(session()->get('error')); ?>

                    </div>
                <?php endif; ?>
            </div>
             <div class="col-md-2">
                <a href="<?php echo e(route('admin.manager.index')); ?>" class = "btn btn-primary" ><i class = "fa fa-backward"></i> Back</a>
            </div>
        </div>
        <br>
        <div class="row">
            <div class="col-md-12">
                <h4>Manager Details</h4>
                <table class="table table-sm table-hover">
                    <tbody>
                        <tr>
                            <td>Customer</td>
                            <td><?php echo e($manager->manager->customer_name); ?></td>
                        </tr>
                        <tr>
                            <td>Social Security Number</td>
                            <td><?php echo e($manager->ssn); ?></td>
                        </tr>
                        <tr>
                            <td>First Name</td>
                            <td><?php echo e($manager->first_name); ?></td>
                        </tr>
                        <tr>
                            <td>Last Name</td>
                            <td><?php echo e($manager->last_name); ?></td>
                        </tr>
                        <tr>
                            <td>Email</td>
                            <td><?php echo e($manager->email); ?></td>
                        </tr>
                        <tr>
                            <td>Phone Number</td>
                            <td><?php echo e($manager->phone); ?></td>
                        </tr>

                        <tr>
                            <td>Address</td>
                            <td><?php echo e($manager->address); ?></td>
                        </tr>
                         <tr>
                            <td>City</td>
                            <td><?php echo e($manager->city); ?></td>
                        </tr>
                        <tr>
                            <td>State</td>
                            <td><?php echo e($manager->state); ?></td>
                        </tr>

                        <tr>
                            <td>Zip Code</td>
                            <td><?php echo e($manager->zipcode); ?></td>
                        </tr>

                        <tr>
                            <td>Job Title</td>
                            <td><?php echo e(ucfirst($manager->job_title)); ?></td>
                        </tr>
                        <tr>
                            <td>Hiring Date</td>
                            <td><?php echo e(\Carbon\Carbon::parse($manager->hiring_date)->format('Y-m-d')); ?></td>
                        </tr>
                        <tr>
                            <td>Fix Pay</td>
                            <td>
                                <?php if($manager->fix_pay): ?>
                                <?php echo e($manager->fix_pay); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>

                        <tr>
                            <td>Hourly Pay</td>
                            <td>
                                <?php if($manager->hourly_pay): ?>
                                <?php echo e($manager->hourly_pay); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>

                        <tr>
                            <td>Weekend Pay</td>
                            <td>
                                <?php if($manager->weekend_pay): ?>
                                <?php echo e($manager->weekend_pay); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>

                        <tr>
                            <td>Overtime Pay</td>
                            <td>
                                <?php if($manager->overtime_pay): ?>
                                <?php echo e($manager->overtime_pay); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/tap4trip/public_html/warehouse/resources/views/admin/managers/show.blade.php ENDPATH**/ ?>