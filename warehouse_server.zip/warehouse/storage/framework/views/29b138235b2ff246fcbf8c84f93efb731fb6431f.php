<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 text-center">
                <h4>Hourly/Fixed Payroll</h4>
                <?php if(session()->has('message')): ?>
                    <div class="alert alert-success text-center">
                        <?php echo e(session()->get('message')); ?>

                    </div>
                <?php endif; ?>
                <?php if(session()->has('error')): ?>
                    <div class="alert alert-danger text-center">
                        <?php echo e(session()->get('error')); ?>

                    </div>
                <?php endif; ?>
            </div>
            
        </div>

    </div>
    <br>
  <!--   <script>
    $('.datatable').DataTable({
        processing: true,
        serverSide: true,
        ajax: {
            url: "<?php echo e(route('admin.inoutloads.index')); ?>",
        },

        columns: [
            {data: 'id', name: 'id', orderable: false, searchable: false, sClass: "align-middle table-image"},
            {data: 'date', name: 'date', orderable: false, searchable: false, sClass: "align-middle table-image"},
            {data: 'load_project_id', name: 'load_project_id', sClass: "align-middle"},
            {data: 'customer_id', name: 'customer_id', sClass: "align-middle"},
            {data: 'load_project_date', name: 'load_project_date', sClass: "align-middle"},
            {data: 'location', name: 'location', sClass: "align-middle"},
            {data: 'bill_to_id', name: 'bill_to_id', sClass: "align-middle"},
            {data: 'action', name: 'action',  searchable: false, sClass:"align-middle"},

        ],
        responsive: true
    });
</script> -->

    <div class="row">
        <div class="col-md-3"></div>
        <div class="col-12 col-md-8 col-lg-8">
            <form action="<?php echo e(route('admin.hourly-fix-report')); ?>" method = "POST" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <div class="form-row">

                  <div class="form-group col-4 col-md-4 col-lg-4">
          <label for="">Employee</label>
          <select name="employee_id" id="" class ="form-control">
           <option value="">Select Employee</option>
           <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($employee->id); ?>"><?php echo e($employee->first_name . ' '. $employee->last_name .' ( SSN-'. $employee->ssn .' )'); ?></option>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>

                <div class="form-group col-4 col-md-4 col-lg-4">
                    <label for="">Start Date</label>
                  <input type="date" class="form-control" name="start_date" id="start_date" required>
              </div>

              <div class="form-group col-4 col-md-4 col-lg-4">
                <label for="">End Date</label>
                  <input type="date" class="form-control" name="end_date" id="end_date" required>
              </div>

        <div class="form-group col-6 col-md-6 col-lg-6 m-auto">
            <label for="" style="visibility: hidden;">Customer </label>
            <input type="submit" name = "submit" id="submit" class = "btn btn-sm btn-primary form-control" value = "Get Hourly/Fixed Payroll">
        </div>
    </div>
</form>
</div>
<div class="col-md-3"></div>
</div>
<br>
<?php if(isset($reports)): ?>
<div class="container">

   <div class="row">
    <?php if($reports->count() > 0): ?>
    <div class="mb-2 text-right w-100">
        

        <a href="<?php echo e(route('admin.export-Hourly-fix-Pay')); ?>"><button type="button" class="btn btn-warning  " data-toggle="modal" data-target="#add_anauncement">
            <i class="fa fa-download"></i> Download
          </button></a>

      </div>
            <div class="col-md-12" style="height: 300px; overflow-y: auto" >
                
                    <table class="table table-bordered data-table">
                        <thead>
                            <th>ID</th>
                            <th>Associate Name</th>
                            <th>Associate Social Security Number</th>
                            <th>Payroll</th>
                            <th>Load/ Project Pay</th>
                            <th>Hourly rate</th>
                            <th>Total Hours </th>
                            <th>Overtime Pay Rate</th>
                            <th>Overtime Hours</th>
                            <th>Total pay</th>

                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                   <td><?php if( $report->id ): ?>
                                    <?php echo e($report->id); ?>

                                    <?php else: ?>
                                    N/A
                                    <?php endif; ?>
                                   </td>
                                   <td><?php if( $report->associate_id ): ?>
                                    <?php echo e($report->associate->first_name .' '. $report->associate->last_name); ?>

                                    <?php else: ?>
                                    N/A
                                    <?php endif; ?>
                                   </td>
                                   <td><?php if( $report->ssn_associate ): ?>
                                    <?php echo e($report->ssn_associate); ?>

                                    <?php else: ?>
                                    N/A
                                    <?php endif; ?>
                                   </td>
                                   <td><?php if( $report->pay_system ): ?>
                                    <?php echo e(ucfirst($report->pay_system)); ?>

                                    <?php else: ?>
                                    N/A
                                    <?php endif; ?>
                                   </td>
                                   <td><?php if( $report->load_details->employee_total_pay ): ?>
                                    <?php echo e($report->load_details->employee_total_pay); ?>

                                    <?php else: ?>
                                    N/A
                                    <?php endif; ?>
                                   </td>
                                   <td><?php if( $report->associate_id ): ?>
                                    <?php echo e($report->associate->hourly_pay); ?>

                                    <?php else: ?>
                                    N/A
                                    <?php endif; ?>
                                   </td>
                                   <td><?php if( $report->hours ): ?>
                                    <?php echo e($report->hours); ?>

                                    <?php else: ?>
                                    N/A
                                    <?php endif; ?>
                                   </td>
                                   <td><?php if( !empty($report->associate->overtime_pay) ): ?>
                                    <?php echo e($report->associate->overtime_pay); ?>

                                    <?php else: ?>
                                    N/A
                                    <?php endif; ?>
                                   </td>
                                    <td>
                                    N/A
                                    
                                   </td>
                                   <td><?php if( $report->payout_associate ): ?>
                                    <?php echo e($report->payout_associate); ?>

                                    <?php else: ?>
                                    N/A
                                    <?php endif; ?>
                                   </td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($reports->links()); ?>

                <?php else: ?>
                    <h4 style = "text-align:center;"><?php echo e($message); ?></h4>
                <?php endif; ?>
            </div>
        </div>
</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/tap4trip/public_html/warehouse/resources/views/admin/reports/hourly-fix-report.blade.php ENDPATH**/ ?>