<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="row">
    <div class="col-md-10 text-center">
      <h4>Update Employee Details</h4>
      <?php if(session()->has('message')): ?>
      <div class="alert alert-success text-center">
        <?php echo e(session()->get('message')); ?>

      </div>
      <?php endif; ?>
      <?php if(session()->has('error')): ?>
      <div class="alert alert-danger text-center">
        <?php echo e(session()->get('error')); ?>

      </div>
      <?php endif; ?>
    </div>
    <div class="col-md-2">
      <a href="<?php echo e(route('admin.employee.index')); ?>" class = "btn btn-primary">View All <i class = "fa fa-eye"></i></a>
    </div>
  </div>
  <br>
  <div class="row">
    <div class="col-md-3"></div>
    <div class="col-md-6">
      <form action="<?php echo e(route('admin.employee.update', $employee->id)); ?>" method = "POST" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <?php echo e(method_field('PUT')); ?>


        <div class="form-row">

          <div class="form-group col-md-12">
           <label for="">Select Customer</label>
           <select class="form-control" name="customer_id" required>
            <option value="<?php echo e($employee->customer_id); ?>"><?php echo e($employee->employee->customer_name); ?></option>
            <?php $__currentLoopData = $employee['warehouses']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($warehouse->id); ?>"><?php echo e($warehouse->customer_name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>

        <div class="form-group col-md-12">
          <label for="">Social Security Number</label>
          <input type="text" class="form-control" pattern="[0-9]{5}" name="ssn" value="<?php echo e($employee->ssn); ?>" placeholder="Enter Last 5 Digits e.g: 12345" required>
        </div>

        <div class="form-group col-md-6">
          <label for="">First Name</label>
          <input type="text" class="form-control" name="first_name" value="<?php echo e($employee->first_name); ?>" placeholder="First Name" required>
        </div>
        <div class="form-group col-md-6">
          <label for="">Last Name</label>
          <input type="text" class="form-control" name="last_name" value="<?php echo e($employee->last_name); ?>" placeholder="Last Name">
        </div>


        <div class="form-group col-md-6">
          <label for="">Email</label>
          <input type="email" class="form-control" name="email" value="<?php echo e($employee->email); ?>" placeholder="emailaddress@example.com" required>
        </div>
        <div class="form-group col-md-6">
          <label for="">Phone</label>
          <input type="text" class="form-control" name="phone" value="<?php echo e($employee->phone); ?>" placeholder="Phone Number">
        </div>
         <div class="form-group col-md-6">
                  <label for="">Password</label>
                  <input type="password" class="form-control" name="password" id="password" placeholder="Password">
              </div>
               <div class="form-group col-md-6">
                  <label for="">Confirm Password</label>
                  <input type="password" class="form-control" name="confrim_password" id="confirm_password" placeholder="Confirm Password">
              </div>
              <div class="form-group col-md-12">
                    <span id='message'></span>
              </div>

              <div class="form-group col-md-12">
                   <input type="checkbox" onclick="toggle()"><b> Show Password</b>
              </div>
        <div class="form-group col-md-12">
          <label for="">Address</label>
          <input type="text" class="form-control" name="address" value="<?php echo e($employee->address); ?>" placeholder="Street, Apartment, or floor">
        </div>
        <div class="form-group col-md-4">
          <label for="">City</label>
          <input type="text" class="form-control" name="city" value="<?php echo e($employee->city); ?>" placeholder="City">
        </div>
        <div class="form-group col-md-4">
          <label for="">State</label>
          <input type="text" class="form-control" name="state" value="<?php echo e($employee->state); ?>" placeholder="State">
        </div>
        <div class="form-group col-md-4">
          <label for="">Zip Code</label>
          <input type="text" class="form-control" name="zipcode" value="<?php echo e($employee->zipcode); ?>" placeholder="e.g: 54000">
        </div>

        

        <div class="form-row">
            <div class="form-group col-md-6">
             <label for="">Fix</label>
             <input type="number" class="form-control" name="fix_pay" placeholder="Enter Fix Pay" value="<?php echo e($employee->fix_pay); ?>">
           </div>
            <div class="form-group col-md-6">
             <label for="">Hourly</label>
             <input type="number" class="form-control" name="hourly_pay" placeholder="Enter Per Hour Pay" value="<?php echo e($employee->hourly_pay); ?>">
           </div>
            <div class="form-group col-md-6">
             <label for="">Overtime</label>
             <input type="number" class="form-control" name="overtime_pay" placeholder="Enter Overtime Pay" value="<?php echo e($employee->overtime_pay); ?>">
           </div>
            <div class="form-group col-md-6">
             <label for="">Weekend</label>
             <input type="number" class="form-control" name="weekend_pay" placeholder="Enter Weekend Pay" value="<?php echo e($employee->weekend_pay); ?>">
           </div>
        </div>

        <div class="form-group col-md-6">
          <label for="">Job Title</label>
          <select name="job_title" class="form-control">
            <option value="<?php echo e($employee->job_title); ?>"><?php echo e($employee->job_title); ?></option>
            <option value="">Select Job Title</option>
            <option value="Loader/Unloader">Loader/Unloader</option>
            <option value="ForkLift Driver">ForkLift Driver</option>
            <option value="Sanitation">Sanitation</option>
            <option value="General Labor">General Labor</option>
            <option value="Yard Driver">Yard Driver</option>
            <option value="Driver">Driver</option>
            <option value="Clerical">Clerical</option>
          </select>
        </div>
        <div class="form-group col-md-6">
          <label for="">Hiring Date</label>
          <input type="date" class="form-control" name="hiring_date" value="<?php echo e(\Carbon\Carbon::parse($employee->hiring_date)->format('Y-m-d')); ?>">
        </div>

      </div>

      <div class="form-group row">
        <label for="" class="col-sm-4 col-form-label"></label>
        <div class="col-md-12">
          <input type="submit" name = "submit" class = "btn btn-sm btn-primary form-control" value = "Update Employee">
        </div>
      </div>

    </form>
  </div>
  <div class="col-md-3"></div>
</div>
</div>
<script>
function toggle() {
  var x = document.getElementById("password");
  var y = document.getElementById("confirm_password");

  if (x.type === "password" && y.type === "password") {

    x.type = "text";
    y.type = "text";
  } else {
    x.type = "password";
    y.type = "password";
  }

}
$(document).ready(function(){
$('#password, #confirm_password').on('keyup', function () {
  if ($('#password').val() == $('#confirm_password').val()) {
    $('#message').html('Password Matching').css('color', 'green');
  } else
    $('#message').html('Password Not Matching').css('color', 'red');
});
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\warehouse\resources\views/admin/employees/edit.blade.php ENDPATH**/ ?>