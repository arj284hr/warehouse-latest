<?php $__env->startSection('content'); ?>
    <div class="container-fluid "style="margin-top:115px;">
        <div class="row">
            <div class="col-md-10 text-center">
                <h4>Managers</h4>
                <?php if(session()->has('message')): ?>
                    <div class="alert alert-success text-center">
                        <?php echo e(session()->get('message')); ?>

                    </div>
                <?php endif; ?>
                <?php if(session()->has('error')): ?>
                    <div class="alert alert-danger text-center">
                        <?php echo e(session()->get('error')); ?>

                    </div>
                <?php endif; ?>
            </div>
            <div class="col-md-2">
                <a href="<?php echo e(route('admin.manager.create')); ?>" class = "btn btn-primary" >Add New <i class = "fa fa-plus"></i></a>
            </div>
        </div>
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6">
                <form action="" method = "POST">
                     
                    <div class="input-group">
                        <input type="text" name = "category_name" class="form-control" placeholder="Search Manager">
                        <div class="input-group-btn">
                            <button class="btn btn-default" type="submit">
                                <i class="glyphicon glyphicon-search"></i>
                            </button>
                        </div>
                    </div>
                </form>
            </div>
            <div class="col-md-3"></div>
        </div>
        <br>
        <div class="row">
            <div class="col-md-12">
                <?php if($managers->count() > 0): ?>
                    <table class="table table-sm table-hover">
                        <thead>
                            <th>ID</th>
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>Email</th>
                            <th>Job Title</th>
                            <th>Customer</th>
                            <th>View</th>
                            <th>Edit</th>
                            <th>Delete</th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $managers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manager): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($manager->id); ?></td>
                                    <td><?php echo e($manager->first_name); ?></td>
                                    <td><?php echo e($manager->last_name); ?></td>
                                    <td><?php echo e($manager->email); ?></td>
                                    <td><?php echo e(ucfirst($manager->job_title)); ?></td>
                                    <td><?php echo e($manager->manager->customer_name); ?></td>
                                   
                                    <td>
                                        <a href="<?php echo e(route('admin.manager.show', $manager->id)); ?>" class = "btn btn-sm btn-info"><i class = "fa fa-eye"></i></a>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('admin.manager.edit', $manager->id)); ?>" class = "btn btn-sm btn-warning"><i class = "fa fa-edit"></i></a>
                                    </td>
                                    <td>
                                        <form action="<?php echo e(route('admin.manager.destroy', $manager->id)); ?>" method = "POST">
                                            <?php echo e(csrf_field()); ?>

                                            <?php echo e(method_field('DELETE')); ?>

                                            <button type = "submit" name = "submit" onclick = "return confirm('Do You Really Want to Delete?')"  class = "btn btn-sm btn-danger"><i class = "fa fa-trash"></i></button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($managers->links()); ?>

                <?php else: ?>
                    <h4 style = "text-align:center;">No Manager Found!</h4>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/tap4trip/public_html/warehouse/resources/views/admin/managers/index.blade.php ENDPATH**/ ?>