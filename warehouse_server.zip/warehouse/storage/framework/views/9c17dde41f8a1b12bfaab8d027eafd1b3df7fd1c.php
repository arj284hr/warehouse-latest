<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-11 text-center">
                <h4>Manager Details</h4>
                <?php if(session()->has('message')): ?>
                    <div class="alert alert-success text-center">
                        <?php echo e(session()->get('message')); ?>

                    </div>
                <?php endif; ?>
                <?php if(session()->has('error')): ?>
                    <div class="alert alert-danger text-center">
                        <?php echo e(session()->get('error')); ?>

                    </div>
                <?php endif; ?>
            </div>
           
        </div>
     
        <br>
        <div class="row">
            <div class="col-md-12">
                <?php if($manager->count() > 0): ?>
                    <table class="table table-sm table-hover">
                        <thead>
                            <th>ID</th>
                            <th>SSN</th>
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Job Title</th>
                            <th>Warehouse</th>
                            <th>View</th>
                          
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $manager; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($manage->id); ?></td>
                                    <td><?php echo e($manage->ssn); ?></td>
                                    <td><?php echo e($manage->first_name); ?></td>
                                    <td><?php echo e($manage->last_name); ?></td>
                                    <td><?php echo e($manage->email); ?></td>
                                    <td><?php echo e($manage->phone); ?></td>
                                    <td><?php echo e(ucfirst($manage->job_title)); ?></td>
                                    <td><?php echo e($manage->manager->warehouse_name); ?></td>
                                   
                                    <td>
                                        <a href="<?php echo e(route('manager.manager.show', $manage->id)); ?>" class = "btn btn-sm btn-info"><i class = "fa fa-eye"></i></a>
                                    </td>
                                 
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    
                <?php else: ?>
                    <h4 style = "text-align:center;">No Manager Found!</h4>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.manager.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/tap4trip/public_html/warehouse/resources/views/manager/manager/index.blade.php ENDPATH**/ ?>