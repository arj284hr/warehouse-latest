<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-10 text-center">
                <h4>View Employee</h4>
                <?php if(session()->has('message')): ?>
                    <div class="alert alert-success text-center">
                        <?php echo e(session()->get('message')); ?>

                    </div>
                <?php endif; ?>
                <?php if(session()->has('error')): ?>
                    <div class="alert alert-danger text-center">
                        <?php echo e(session()->get('error')); ?>

                    </div>
                <?php endif; ?>
            </div>
             <div class="col-md-2">
                <a href="<?php echo e(route('admin.employee.index')); ?>" class = "btn btn-primary" ><i class = "fa fa-backward"></i> Back</a>
            </div>
        </div>
        <br>
        <div class="row">
            <div class="col-md-12">
                <h4>Employee Details</h4>
                <table class="table table-sm table-hover">
                    <tbody>
                        <tr>
                            <td>Customer</td>
                            <td><?php echo e($employee->employee->customer_name); ?></td>
                        </tr>
                        <tr>
                            <td>Social Security Number</td>
                            <td><?php echo e($employee->ssn); ?></td>
                        </tr>
                        <tr>
                            <td>First Name</td>
                            <td><?php echo e($employee->first_name); ?></td>
                        </tr>
                        <tr>
                            <td>Last Name</td>
                            <td><?php echo e($employee->last_name); ?></td>
                        </tr>
                        <tr>
                            <td>Email</td>
                            <td><?php echo e($employee->email); ?></td>
                        </tr>
                        <tr>
                            <td>Phone Number</td>
                            <td><?php echo e($employee->phone); ?></td>
                        </tr>

                        <tr>
                            <td>Address</td>
                            <td><?php echo e($employee->address); ?></td>
                        </tr>
                        <tr>
                            <td>City</td>
                            <td><?php echo e($employee->city); ?></td>
                        </tr>
                        <tr>
                            <td>State</td>
                            <td><?php echo e($employee->state); ?></td>
                        </tr>
                        <tr>
                            <td>Zip Code</td>
                            <td><?php echo e($employee->zipcode); ?></td>
                        </tr>

                        <tr>
                            <td>Job Title</td>
                            <td><?php echo e(ucfirst($employee->job_title)); ?></td>
                        </tr>
                        <tr>
                            <td>Hiring Date</td>
                            <td><?php echo e(\Carbon\Carbon::parse($employee->hiring_date)->format('Y-m-d')); ?></td>
                        </tr>

                        <tr>
                            <td>Fix Pay</td>
                            <td>
                                <?php if($employee->fix_pay): ?>
                                <?php echo e($employee->fix_pay); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>

                        <tr>
                            <td>Hourly Pay</td>
                            <td>
                                <?php if($employee->hourly_pay): ?>
                                <?php echo e($employee->hourly_pay); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>

                        <tr>
                            <td>Weekend Pay</td>
                            <td>
                                <?php if($employee->weekend_pay): ?>
                                <?php echo e($employee->weekend_pay); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>

                        <tr>
                            <td>Overtime Pay</td>
                            <td>
                                <?php if($employee->overtime_pay): ?>
                                <?php echo e($employee->overtime_pay); ?>

                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                            </td>
                        </tr>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/tap4trip/public_html/warehouse/resources/views/admin/employees/show.blade.php ENDPATH**/ ?>