<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-10 text-center">
                <h4>Employees</h4>
                <?php if(session()->has('message')): ?>
                    <div class="alert alert-success text-center">
                        <?php echo e(session()->get('message')); ?>

                    </div>
                <?php endif; ?>
                <?php if(session()->has('error')): ?>
                    <div class="alert alert-danger text-center">
                        <?php echo e(session()->get('error')); ?>

                    </div>
                <?php endif; ?>
            </div>
            <div class="col-md-2">
                <a href="<?php echo e(route('admin.employee.create')); ?>" class = "btn btn-primary" >Add New <i class = "fa fa-plus"></i></a>
            </div>
        </div>
   
        <br>
        <div class="row">
            <div class="col-md-12">
                <?php if($employees->count() > 0): ?>
                    <table class="table table-sm table-hover">
                        <thead>
                            <th>ID</th>
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>Email</th>
                            <th>Job Title</th>
                            <th>Customer</th>
                            <th>View</th>
                            <th>Edit</th>
                            <th>Delete</th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($employee->id); ?></td>
                                    <td><?php echo e($employee->first_name); ?></td>
                                    <td><?php echo e($employee->last_name); ?></td>
                                    <td><?php echo e($employee->email); ?></td>
                                    <td><?php echo e(ucfirst($employee->job_title)); ?></td>
                                    <td><?php echo e($employee->employee->customer_name); ?></td>
                                   
                                    <td>
                                        <a href="<?php echo e(route('admin.employee.show', $employee->id)); ?>" class = "btn btn-sm btn-info"><i class = "fa fa-eye"></i></a>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('admin.employee.edit', $employee->id)); ?>" class = "btn btn-sm btn-warning"><i class = "fa fa-edit"></i></a>
                                    </td>
                                    <td>
                                        <form action="<?php echo e(route('admin.employee.destroy', $employee->id)); ?>" method = "POST">
                                            <?php echo e(csrf_field()); ?>

                                            <?php echo e(method_field('DELETE')); ?>

                                            <button type = "submit" name = "submit" onclick = "return confirm('Do You Really Want to Delete?')"  class = "btn btn-sm btn-danger"><i class = "fa fa-trash"></i></button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($employees->links()); ?>

                <?php else: ?>
                    <h4 style = "text-align:center;">No Manager Found!</h4>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/tap4trip/public_html/warehouse/resources/views/admin/employees/index.blade.php ENDPATH**/ ?>