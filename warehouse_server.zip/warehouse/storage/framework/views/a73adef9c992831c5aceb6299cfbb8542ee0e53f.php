<div id="sidebar-wrapper" style = "margin-top: 11px;">
      <ul class="sidebar-nav nav-pills nav-stacked" id="menu">
        <li class="active">
          <a href="<?php echo e(route('manager.dashboard')); ?>"><span class="fa-stack fa-lg pull-left"><i class="fa fa-dashboard fa-stack-1x "></i></span> Dashboard</a>
         
        </li>
        <li>
          <a href=""><span class="fa-stack fa-lg pull-left"><i class="fa fa-users fa-stack-1x "></i></span>Profile &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;<i class = "fa fa-chevron-down"></i></a>
          <ul class="nav-pills nav-stacked" style="list-style-type:none;">
            <li><a href="<?php echo e(route('manager.manager.index')); ?>"><i class = "fa fa-user"></i>&emsp;Manager</a></li>
            <li><a href=""><i class = "fa fa-user"></i>&emsp;Change Password</a></li>
          </ul>
        </li>
        
            <li>
                <a href=""><span class="fa-stack fa-lg pull-left"><i class="fa fa-product-hunt fa-stack-1x "></i></span>Employees &emsp;&emsp;&emsp;&emsp;&emsp;<i class = "fa fa-chevron-down"></i></a>
                <ul class="nav-pills nav-stacked" style="list-style-type:none;">
                  <li><a href="<?php echo e(route('manager.employee.index')); ?>"><i class = "fa fa-product-hunt"></i>&emsp;All Employee</a></li>
                  <li><a href=""><i class = "fa fa-product-hunt"></i>&emsp;Add Employee</a></li>
                  
                </ul>
              </li>
                <li>
          <a href="<?php echo e(route('manager.inoutloads.index')); ?>"><i class="fa fa-cart-plus"></i>&emsp;Loads</a>
        </li>

       
             
      </ul>
    </div>
<?php /**PATH C:\xampp\htdocs\warehouse\resources\views/layouts/manager/sidenav.blade.php ENDPATH**/ ?>