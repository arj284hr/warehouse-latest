<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-8 text-center">
                <h4>Customer</h4>
                <?php if(session()->has('message')): ?>
                    <div class="alert alert-success text-center">
                        <?php echo e(session()->get('message')); ?>

                    </div>
                <?php endif; ?>
                <?php if(session()->has('error')): ?>
                    <div class="alert alert-danger text-center">
                        <?php echo e(session()->get('error')); ?>

                    </div>
                <?php endif; ?>
            </div>
         <div class="col-md-4">
                <a href="<?php echo e(route('admin.warehouse.index')); ?>" class = "btn btn-primary" ><i class = "fa fa-backward"></i> Back</a>
                <a href="<?php echo e(route('admin.warehouse.create')); ?>" class = "btn btn-primary" >Add Customer <i class = "fa fa-plus"></i>
            </a>
        </div>

        </div>
        
        <br>
        <div class="row">
            <div class="col-md-12">
                <h4>Customer Details</h4>
                <table class="table table-sm table-hover">
                    <tbody>
                        <tr>
                            <td>Customer Name</td>
                            <td><?php echo e($warehouse->customer_name); ?></td>
                        </tr>
                        <tr>
                            <td>Street Address</td>
                            <td><?php echo e($warehouse->street_address); ?></td>
                        </tr>
                        <tr>
                            <td>City</td>
                            <td><?php echo e($warehouse->city); ?></td>
                        </tr>
                         <tr>
                            <td>State</td>
                            <td><?php echo e($warehouse->state); ?></td>
                        </tr>
                        <tr>
                            <td>Zip Code</td>
                            <td><?php echo e($warehouse->zipcode); ?></td>
                        </tr>
                        <tr>
                            <td>Shift</td>
                            <td>Morning</td>
                        </tr>
                        
                        <tr>
                            <td>Opening Time</td>
                            <td><?php echo e(\Carbon\Carbon::parse($warehouse->morning_opening_time)->format('H:i')); ?></td> 
                        </tr>
                        <tr>
                            <td>Closing Time</td>
                            <td><?php echo e(\Carbon\Carbon::parse($warehouse->morning_closing_time)->format('H:i')); ?></td>
                        </tr>
                         <tr>
                            <td>Shift</td>
                            <td>Evening</td>
                        </tr>
                        <tr>
                            <td>Opening Time</td>
                            <td><?php echo e(\Carbon\Carbon::parse($warehouse->evening_opening_time)->format('H:i')); ?></td>
                        </tr>
                        <tr>
                            <td>Closing Time</td>
                            <td><?php echo e(\Carbon\Carbon::parse($warehouse->evening_closing_time)->format('H:i')); ?></td>
                        </tr>
                         <tr>
                            <td>Shift</td>
                            <td>Night</td>
                        </tr>
                        <tr>
                            <td>Opening Time</td>
                            <td><?php echo e(\Carbon\Carbon::parse($warehouse->night_opening_time)->format('H:i')); ?></td>
                        </tr>
                        <tr>
                            <td>Closing Time</td>
                            <td><?php echo e(\Carbon\Carbon::parse($warehouse->night_closing_time)->format('H:i')); ?></td>
                        </tr>
                         <tr>
                            <td>Shift</td>
                            <td>Weekend</td>
                        </tr>
                        <tr>
                            <td>Opening Time</td>
                            <td><?php echo e(\Carbon\Carbon::parse($warehouse->weekend_opening_time)->format('H:i')); ?></td>
                        </tr>
                        <tr>
                            <td>Closing Time</td>
                            <td><?php echo e(\Carbon\Carbon::parse($warehouse->weekend_closing_time)->format('H:i')); ?></td>
                        </tr>



                    </tbody>
                </table>
            </div>
        </div>

        


        

            <div class="row">
            <div class="col-md-10 text-center">
                <h4>Manager</h4>
                <?php if(session()->has('message')): ?>
                    <div class="alert alert-success text-center">
                        <?php echo e(session()->get('message')); ?>

                    </div>
                <?php endif; ?>
                <?php if(session()->has('error')): ?>
                    <div class="alert alert-danger text-center">
                        <?php echo e(session()->get('error')); ?>

                    </div>
                <?php endif; ?>
            </div>

         <div class="col-md-2">
            <a href="<?php echo e(route('admin.manager.create')); ?>" class = "btn btn-sm btn-primary" >Add Manager <i class = "fa fa-plus"></i>
            </a>
        </div>

        </div>
        <br>
        <br>
        <div class="row">
            <div class="col-md-12">
                <h4>Customer Manager</h4>
             <?php if(!empty($warehouse->manager)): ?>

                <table class="table table-sm table-hover">
                    <thead>
                        <th>ID</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Email</th>
                        <th>Job Title</th>
                        <th>Customer</th>
                        <th>View</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $warehouse->manager; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manager): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                         <td><?php echo e($manager->id); ?></td>
                             <td><?php echo e($manager->first_name); ?></td>
                            <td><?php echo e($manager->last_name); ?></td>
                             <td><?php echo e($manager->email); ?></td>
                            <td><?php echo e(ucfirst($manager->job_title)); ?></td>
                            <td><?php echo e($manager->manager->customer_name); ?></td>
                            <td>
                                <a href="<?php echo e(route('admin.manager.show', $manager->id)); ?>" class = "btn btn-sm btn-info"><i class = "fa fa-eye"></i></a>
                            </td>
                            <td>
                                <a href="<?php echo e(route('admin.manager.edit', $manager->id)); ?>" class = "btn btn-sm btn-warning"><i class = "fa fa-edit"></i></a>
                            </td>
                            <td>
                                <form action="<?php echo e(route('admin.manager.destroy', $manager->id)); ?>" method = "POST">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('DELETE')); ?>

                                    <button type = "submit" name = "submit" onclick = "return confirm('Do You Really Want to Delete?')"  class = "btn btn-sm btn-danger"><i class = "fa fa-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
                 <?php else: ?>
                    <h4 style = "text-align:center;">No Manager Found!</h4>
                <?php endif; ?>

            </div>
        </div>

        


         

            <div class="row">
            <div class="col-md-10 text-center">
                <h4>Employee</h4>
                <?php if(session()->has('message')): ?>
                    <div class="alert alert-success text-center">
                        <?php echo e(session()->get('message')); ?>

                    </div>
                <?php endif; ?>
                <?php if(session()->has('error')): ?>
                    <div class="alert alert-danger text-center">
                        <?php echo e(session()->get('error')); ?>

                    </div>
                <?php endif; ?>
            </div>

         <div class="col-md-2">
            <a href="<?php echo e(route('admin.employee.create')); ?>" class = "btn btn-sm btn-primary" >Add Employee <i class = "fa fa-plus"></i>
            </a>
        </div>
        </div>
        <br>
         <br>
        <div class="row">
            <div class="col-md-12">
                <h4>Customer Employees</h4>
                <?php if(!empty($warehouse->employee)): ?>

                    <table class="table table-sm table-hover">
                        <thead>
                            <th>ID</th>
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>Email</th>
                            <th>Job Title</th>
                            <th>Customer</th>
                            <th>View</th>
                            <th>Edit</th>
                            <th>Delete</th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $warehouse->employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($employee->id); ?></td>
                                    <td><?php echo e($employee->first_name); ?></td>
                                    <td><?php echo e($employee->last_name); ?></td>
                                    <td><?php echo e($employee->email); ?></td>
                                    <td><?php echo e(ucfirst($employee->job_title)); ?></td>
                                    <td><?php echo e($employee->employee->customer_name); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('admin.employee.show', $employee->id)); ?>" class = "btn btn-sm btn-info"><i class = "fa fa-eye"></i></a>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('admin.employee.edit', $employee->id)); ?>" class = "btn btn-sm btn-warning"><i class = "fa fa-edit"></i></a>
                                    </td>
                                    <td>
                                        <form action="<?php echo e(route('admin.employee.destroy', $employee->id)); ?>" method = "POST">
                                            <?php echo e(csrf_field()); ?>

                                            <?php echo e(method_field('DELETE')); ?>

                                            <button type = "submit" name = "submit" onclick = "return confirm('Do You Really Want to Delete?')"  class = "btn btn-sm btn-danger"><i class = "fa fa-trash"></i></button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    
                <?php else: ?>
                    <h4 style = "text-align:center;">No Employee Found!</h4>
                <?php endif; ?>
            </div>
        </div>

         
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/tap4trip/public_html/warehouse/resources/views/admin/warehouses/show.blade.php ENDPATH**/ ?>