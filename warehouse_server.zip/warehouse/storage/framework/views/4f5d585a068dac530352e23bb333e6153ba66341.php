
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="row">
    <div class="col-md-10 text-center">
      <h4>Update Customer</h4>
      <?php if(session()->has('message')): ?>
      <div class="alert alert-success text-center">
        <?php echo e(session()->get('message')); ?>

      </div>
      <?php endif; ?>
      <?php if(session()->has('error')): ?>
      <div class="alert alert-danger text-center">
        <?php echo e(session()->get('error')); ?>

      </div>
      <?php endif; ?>
    </div>
    <div class="col-md-2">
      <a href="<?php echo e(route('admin.warehouse.index')); ?>" class = "btn btn-primary">View All <i class = "fa fa-eye"></i></a>
    </div>
  </div>
  <br>
  <div class="row">
    <div class="col-md-3"></div>
    <div class="col-md-6">
      <form action="<?php echo e(route('admin.warehouse.update', $warehouse->id)); ?>" method = "POST" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <?php echo e(method_field('PUT')); ?>


        <div class="form-row">
           <div class="form-group col-md-12">
            <label for="">Customer Name</label>
            <input type="text" class="form-control" name="customer_name" placeholder="Enter Customer Name" required value="<?php echo e($warehouse->customer_name); ?>">
          </div>
          <div class="form-group col-md-12">
            <label for="">Street Address</label>
            <input type="text" class="form-control" name="street_address" placeholder="Enter Street Address" value="<?php echo e($warehouse->street_address); ?>">
          </div>
             <div class="form-group col-md-4">
            <label for="">City</label>
            <input type="text" class="form-control" name="city" placeholder="City" value="<?php echo e($warehouse->city); ?>">
          </div>
          <div class="form-group col-md-4">
            <label for="">State</label>
            <input type="text" class="form-control" name="state" placeholder="State" value="<?php echo e($warehouse->state); ?>">
          </div>
          <div class="form-group col-md-4">
            <label for="">Zip Code</label>
            <input type="text" class="form-control" name="zipcode" placeholder="Zip Code"  value="<?php echo e($warehouse->zipcode); ?>">
          </div>
           <div class="form-group col-md-12">
            <label for="">All Shifts</label>
            
          </div>

            <div class="form-group col-md-4">
            <label for="">Morning Shift</label>
            
          </div>

          <div class="form-group col-md-4">
            <label for="">Openinig Time</label>
            <input type="time" class="form-control" name="morning_opening_time" value="<?php echo e(\Carbon\Carbon::parse($warehouse->morning_opening_time)->format('H:i')); ?>">
          </div>
          <div class="form-group col-md-4">
            <label for="">Closing Time</label>
            <input type="time" class="form-control" name="morning_closing_time" value="<?php echo e(\Carbon\Carbon::parse($warehouse->morning_closing_time)->format('H:i')); ?>">
          </div>
              <div class="form-group col-md-4">
            <label for="">Evening Shift</label>
           
          </div>
          <div class="form-group col-md-4">
            <label for="">Openinig Time</label>
            <input type="time"   class="form-control" name="evening_opening_time" value="<?php echo e(\Carbon\Carbon::parse($warehouse->evening_opening_time)->format('H:i')); ?>">
          </div>
          <div class="form-group col-md-4">
            <label for="">Closing Time</label>
            <input type="time" class="form-control" name="evening_closing_time" value="<?php echo e(\Carbon\Carbon::parse($warehouse->evening_closing_time)->format('H:i')); ?>">
          </div>
              <div class="form-group col-md-4">
            <label for="">Night Shift</label>
           
          </div>
           <div class="form-group col-md-4">
            <label for="">Openinig Time</label>
            <input type="time"   class="form-control" name="night_opening_time" value="<?php echo e(\Carbon\Carbon::parse($warehouse->night_opening_time)->format('H:i')); ?>">
          </div>
          <div class="form-group col-md-4">
            <label for="">Closing Time</label>
            <input type="time" class="form-control" name="night_closing_time" value="<?php echo e(\Carbon\Carbon::parse($warehouse->night_closing_time)->format('H:i')); ?>">
          </div>
              <div class="form-group col-md-4">
            <label for="">Weekend Shift</label>
           
          </div>
          <div class="form-group col-md-4">
            <label for="">Openinig Time</label>
            <input type="time"   class="form-control" name="weekend_opening_time" value="<?php echo e(\Carbon\Carbon::parse($warehouse->weekend_opening_time)->format('H:i')); ?>">
          </div>
          <div class="form-group col-md-4">
            <label for="">Closing Time</label>
            <input type="time" class="form-control" name="weekend_closing_time" value="<?php echo e(\Carbon\Carbon::parse($warehouse->weekend_closing_time)->format('H:i')); ?>">
          </div>
        </div>
        <div class="col-md-4">
          <input type="hidden" name = "" class = "" value = "">
        </div>
        <div class="col-md-5">
          <input type="submit" name = "submit" class = "btn btn-sm btn-primary form-control" value = "Update Customer">
        </div>
        
      </form>
    </div>
    <div class="col-md-3"></div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/tap4trip/public_html/warehouse/resources/views/admin/warehouses/edit.blade.php ENDPATH**/ ?>