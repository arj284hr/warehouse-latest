<nav class="navbar navbar-default no-margin navbar-fixed-top">    
    <div class="fixed-brand">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" id="menu-toggle">
            <span class="glyphicon glyphicon-th-large" aria-hidden="true"></span>
        </button>
        <a class="navbar-brand" href="#"><i class=""></i>Warehouse!</a>        
        
    </div>
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
        <ul class="nav navbar-nav">
            <li class="active">
                <button class="navbar-toggle collapse in" data-toggle="collapse" id="menu-toggle-2" style = "display: none;"> <span class="glyphicon glyphicon-th-large" aria-hidden="true"></span></button>
            </li>
            <li id = "dp">
                <a href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre >
                    <?php echo e(Auth::user()->first_name); ?> <span class="caret"></span>
                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                    <a id = "dpa" class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                        document.getElementById('logout-form').submit();"><?php echo e(__('Logout')); ?> 
                    </a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                </div>
            </li>
        </ul>
    </div>    
</nav><?php /**PATH /home4/tap4trip/public_html/warehouse/resources/views/layouts/manager/navbar.blade.php ENDPATH**/ ?>