


 <header class="header body-pd" id="header">
        <div class="header__toggle d-flex align-items-center">
            <i class='bx bx-menu' id="header-toggle"></i>
            <span class="pl-4 for-hide-dash">Dashboard</span>
        </div>

        <div class="">
            <div class="row">
                <div class="col-md-12">
                    <nav class="navbar navbar-expand-lg navbar-light ">
                        <ul class="navbar-nav d-flex align-items-center flex-row cus-padd">
                         
                        
                        <li class="nav-item dropdown d-flex justify-content-end" width="auto">
                            <a class="nav-link dropdown-toggle d-flex" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                              <p class="pr-3 mb-0 d-flex align-items-center"><?php echo e(Auth::user()->first_name); ?></p> <img 
                              src="<?php echo e(asset('/assets/img/avatar.png')); ?>" alt="User" class="rounded-circle img-fluid" width="40px" >
                          </a>
                          <div class="dropdown-menu dropdown-menu2" aria-labelledby="navbarDropdownMenuLink">
                              <a class="dropdown-item" href="#">Profile</a>
                            
                               <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                        document.getElementById('logout-form').submit();"><?php echo e(__('Logout')); ?> 
                    </a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                          </div>
                      </li>
                  </ul>

              </nav>
          </div>
      </div>
  </div>
</header>
<?php /**PATH /home4/tap4trip/public_html/warehouse/resources/views/layouts/admin/navbar.blade.php ENDPATH**/ ?>