<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-10 text-center">
                <h4>Update Product</h4>
                <?php if(session()->has('message')): ?>
                    <div class="alert alert-success text-center">
                        <?php echo e(session()->get('message')); ?>

                    </div>
                <?php endif; ?>
                <?php if(session()->has('error')): ?>
                    <div class="alert alert-danger text-center">
                        <?php echo e(session()->get('error')); ?>

                    </div>
                <?php endif; ?>
            </div>
            <div class="col-md-2">
                <a href="<?php echo e(route('admin.departments.index')); ?>" class = "btn btn-primary">View All <i class = "fa fa-eye"></i></a>
            </div>
        </div>
        <br>
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6">
                <form action="<?php echo e(route('admin.departments.update', $department->id)); ?>" method = "POST" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('PUT')); ?>


                 <div class="form-row">

                <div class="form-group col-md-8">
                  <input type="text" class="form-control" name="department_name" placeholder="Enter Product Name" required value="<?php echo e($department->department_name); ?>">
              </div>

        <div class="form-group col-md-4">
            <input type="submit" name = "submit" class = "btn btn-sm btn-primary form-control" value = "Update Product">
        </div>
    </div>
                </form>
            </div>
            <div class="col-md-3"></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/tap4trip/public_html/warehouse/resources/views/admin/departments/edit.blade.php ENDPATH**/ ?>