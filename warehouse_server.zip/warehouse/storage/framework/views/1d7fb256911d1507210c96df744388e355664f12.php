
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 text-center">
                <h4>Driver Invoice</h4>
                <?php if(session()->has('message')): ?>
                    <div class="alert alert-success text-center">
                        <?php echo e(session()->get('message')); ?>

                    </div>
                <?php endif; ?>
                <?php if(session()->has('error')): ?>
                    <div class="alert alert-danger text-center">
                        <?php echo e(session()->get('error')); ?>

                    </div>
                <?php endif; ?>
            </div>
            
        </div>
 
    </div>
    <br>
  <!--   <script>
    $('.datatable').DataTable({
        processing: true,
        serverSide: true,
        ajax: {
            url: "<?php echo e(route('admin.inoutloads.index')); ?>",
        },
         
        columns: [
            {data: 'id', name: 'id', orderable: false, searchable: false, sClass: "align-middle table-image"},
            {data: 'date', name: 'date', orderable: false, searchable: false, sClass: "align-middle table-image"},
            {data: 'load_project_id', name: 'load_project_id', sClass: "align-middle"},
            {data: 'customer_id', name: 'customer_id', sClass: "align-middle"},
            {data: 'load_project_date', name: 'load_project_date', sClass: "align-middle"},
            {data: 'location', name: 'location', sClass: "align-middle"},
            {data: 'bill_to_id', name: 'bill_to_id', sClass: "align-middle"},
            {data: 'action', name: 'action',  searchable: false, sClass:"align-middle"},
        
        ],
        responsive: true
    });
</script> -->

    <div class="row">
        <div class="col-md-3"></div>
        <div class="col-12 col-md-8 col-lg-8">
            <form action="<?php echo e(route('admin.driver-invoice')); ?>" method = "POST" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <div class="form-row">

                  <div class="form-group col-4 col-md-4 col-lg-4">
          <label for="">Driver</label>
          <select name="driver_id" id="" class ="form-control">
           <option value="">Select Driver</option>
           <?php $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <option value="<?php echo e($driver->id); ?>"><?php echo e($driver->first_name .' '.$driver->last_name); ?></option>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
          </select>  
        </div>
                
                <div class="form-group col-4 col-md-4 col-lg-4">
                    <label for="">Start Date</label>
                  <input type="date" class="form-control" name="start_date" id="start_date" required>
              </div>
             
              <div class="form-group col-4 col-md-4 col-lg-4">
                <label for="">End Date</label>
                  <input type="date" class="form-control" name="end_date" id="end_date" required>
              </div>
             
        <div class="form-group col-6 col-md-6 col-lg-6 m-auto">
            
            <input type="submit" name = "submit" id="submit" class = "btn btn-sm btn-primary form-control" value = "Get Driver Invoice">
        </div>
    </div>
</form>
</div>
<div class="col-md-3"></div>
</div>
<br>
<?php if(isset($invoices)): ?>
<div class="container">
   
   <div class="row">
    <?php if($invoices->count() > 0): ?>
    <div class="mb-2 text-right w-100">
        

        <a href="<?php echo e(route('admin.export-driver-excel')); ?>"><button type="button" class="btn btn-warning  " data-toggle="modal" data-target="#add_anauncement">
            <i class="fa fa-download"></i> Download
          </button></a>

      </div>
            <div class="col-md-12 text-right" style="height: 300px; overflow-y: auto">
                
                    <table class="table table-bordered data-table">
                        <thead>
                            <th>ID</th>
                           
                            
                            <th>Bill to</th>
                            <th>Load/Project Control No</th>
                            <th>Load/Project Date</th>
                            <th>Load/Project Type</th>
                            <th>Location</th>
                            <th>Product</th>
                            <th>Shift</th>
                            <th>Trailer Type</th>
                            <th>Trailer Size</th>
                            <th>In/Out Load/Project</th>
                            <th>Door No.</th>  
                            <th>Weight</th>
                           
                            <th>Begin Case Ct</th>
                            <th>Ending Case Ct</th>
                            <th>Total Skus</th>
                            <th>Pieces</th>
                            
                            <th>Total load/project Charge</th>
                            
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                   <td><?php if( $invoice->id ): ?>
                                    <?php echo e($invoice->id); ?>

                                    <?php else: ?>
                                    N/A
                                    <?php endif; ?>
                                   </td>
                                    
                                   <td><?php if( $invoice->bill_to_id ): ?>
                                    <?php echo e($invoice->bill_to_id); ?>

                                    <?php else: ?>
                                    N/A
                                    <?php endif; ?>
                                   </td>
                                   <td><?php if( $invoice->load_project_control_no ): ?>
                                    <?php echo e($invoice->load_project_control_no); ?>

                                    <?php else: ?>
                                    N/A
                                    <?php endif; ?>
                                   </td>
                                   <td><?php if( $invoice->load_project_date ): ?>
                                    <?php echo e($invoice->load_project_date); ?>

                                    <?php else: ?>
                                    N/A
                                    <?php endif; ?>
                                   </td>
                                   <td><?php if( $invoice->load_type ): ?>
                                    <?php echo e($invoice->load_type); ?>

                                    <?php else: ?>
                                    N/A
                                    <?php endif; ?>
                                   </td>
                                   <td><?php if( $invoice->location_id ): ?>
                                    <?php echo e($invoice->location_id); ?>

                                    <?php else: ?>
                                    N/A
                                    <?php endif; ?>
                                   </td>
                                   <td><?php if( $invoice->department_id ): ?>
                                    <?php echo e($invoice->department_id); ?>

                                    <?php else: ?>
                                    N/A
                                    <?php endif; ?>
                                   </td>
                                   <td><?php if( $invoice->shift ): ?>
                                    <?php echo e($invoice->shift); ?>

                                    <?php else: ?>
                                    N/A
                                    <?php endif; ?>
                                   </td>
                                   <td><?php if( $invoice->trailer_type ): ?>
                                    <?php echo e($invoice->trailer_type); ?>

                                    <?php else: ?>
                                    N/A
                                    <?php endif; ?>
                                   </td>
                                   <td><?php if( $invoice->trailer_size ): ?>
                                    <?php echo e($invoice->trailer_size); ?>

                                    <?php else: ?>
                                    N/A
                                    <?php endif; ?>
                                   </td>
                                   <td><?php if( $invoice->in_out_load ): ?>
                                    <?php echo e($invoice->in_out_load); ?>

                                    <?php else: ?>
                                    N/A
                                    <?php endif; ?>
                                   </td>
                                   <td><?php if( $invoice->door_no ): ?>
                                    <?php echo e($invoice->door_no); ?>

                                    <?php else: ?>
                                    N/A
                                    <?php endif; ?>
                                   </td>
                                   <td><?php if( $invoice->weight ): ?>
                                    <?php echo e($invoice->weight); ?>

                                    <?php else: ?>
                                    N/A
                                    <?php endif; ?>
                                   </td>
                                   
                                   <td><?php if( $invoice->begin_case_ct ): ?>
                                    <?php echo e($invoice->begin_case_ct); ?>

                                    <?php else: ?>
                                    N/A
                                    <?php endif; ?>
                                   </td>
                                   <td><?php if( $invoice->ending_case_ct ): ?>
                                    <?php echo e($invoice->ending_case_ct); ?>

                                    <?php else: ?>
                                    N/A
                                    <?php endif; ?>
                                   </td>
                                   <td><?php if( $invoice->total_skus ): ?>
                                    <?php echo e($invoice->total_skus); ?>

                                    <?php else: ?>
                                    N/A
                                    <?php endif; ?>
                                   </td>
                                   <td><?php if( $invoice->pieces ): ?>
                                    <?php echo e($invoice->pieces); ?>

                                    <?php else: ?>
                                    N/A
                                    <?php endif; ?>
                                   </td>
                                 
                                   <td><?php if( $invoice->charge_amount ): ?>
                                    <?php echo e($invoice->charge_amount); ?>

                                    <?php else: ?>
                                    N/A
                                    <?php endif; ?>
                                   </td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($invoices->links()); ?>

                <?php else: ?>
                    <h4 style = "text-align:center;"><?php echo e($message); ?></h4>
                <?php endif; ?>
            </div>
        </div>
</div>
<?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/tap4trip/public_html/warehouse/resources/views/admin/reports/driver-invoice.blade.php ENDPATH**/ ?>