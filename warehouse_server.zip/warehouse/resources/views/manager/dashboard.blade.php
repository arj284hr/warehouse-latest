@extends('layouts.manager.app')
@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <h4>Manager Panel</h4>
            </div>
        </div>
    </div>
@endsection