@extends('layouts.admin.app')
@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <h4>Admin Panel</h4>
            </div>
        </div>
    </div>
@endsection